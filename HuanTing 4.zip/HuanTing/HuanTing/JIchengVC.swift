//
//  JIchengVC.swift
//  HuanTing
//
//  Created by Jung Jessica on 2022/8/31.
//

import Foundation
import UIKit

class JiChengVC: MusicViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        super.One.setBackgroundImage(UIImage(named: "2"), for: .normal)
        view.addSubview(super.One)
    }
}
