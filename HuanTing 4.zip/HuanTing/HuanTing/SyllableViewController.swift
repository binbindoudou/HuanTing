//
//  SyllableViewController.swift
//  HuanTing
//
//  Created by Jung Jessica on 2022/8/30.
//

import UIKit
import AVFoundation

class SyllableViewController: UIViewController {
    var syllableaudioPlayer: AVAudioPlayer  = AVAudioPlayer()
    var syllableBackground: UIImageView!
    var syllablebackButton: UIButton!
    var syllableButton: UIButton!
//    var syllableSettingButton: UIButton!
    var syllableNextButton: UIButton!
    var syllableLastButton: UIButton!
    var syllableOne: UIButton!
    var syllableTwo: UIButton!
    var syllableThree: UIButton!
    var syllableFour: UIButton!
    var syllabletrueimageView: UIImageView!
    var syllableerroimageView: UIImageView!
    

    override func viewDidLoad() {
        
        super.viewDidLoad()

        syllablebackButton = UIButton(frame: CGRect(x: view.frame.width/40, y: view.frame.height/26, width: view.frame.width/8, height: view.frame.height/6))
        syllablebackButton.setBackgroundImage(UIImage(named: "back"), for: .normal)
        syllablebackButton.addTarget(self, action: #selector(clickSyllableOne), for:.touchUpInside)
        
        syllableBackground = UIImageView(frame: CGRect(x: 0, y: 0, width: view.frame.width, height: view.frame.height))
        syllableBackground.image = UIImage(named: "background")
        
//        syllableSettingButton = UIButton(frame: CGRect(x: view.frame.width*7/8, y: view.frame.height/50, width: view.frame.width/8, height: view.frame.height/6))
//        syllableSettingButton.setBackgroundImage(UIImage(named: "setting"), for: .normal)
//        syllableSettingButton.addTarget(self, action: #selector(clickSyllableTwo), for:.touchUpInside)
        
        syllableOne = UIButton(frame: CGRect(x: view.frame.width*4/60, y: view.frame.height*17/40, width: view.frame.width/8, height: view.frame.height/6))
        syllableOne.setBackgroundImage(UIImage(named: "a"), for: .normal)
        syllableOne.addTarget(self, action: #selector(clickSyllableThree), for:.touchUpInside)
        
        syllableTwo = UIButton(frame: CGRect(x: view.frame.width*18/60, y: view.frame.height*13/40, width: view.frame.width/8, height: view.frame.height/7))
        syllableTwo.setBackgroundImage(UIImage(named: "o"), for: .normal)
        syllableTwo.addTarget(self, action: #selector(clickSyllableFour), for:.touchUpInside)
        
        syllableThree = UIButton(frame: CGRect(x: view.frame.width*32/60, y: view.frame.height*13/40, width: view.frame.width/8, height: view.frame.height/7))
        syllableThree.setBackgroundImage(UIImage(named: "e"), for: .normal)
        syllableThree.addTarget(self, action: #selector(clickSyllableFive), for:.touchUpInside)
        
        syllableFour = UIButton(frame: CGRect(x: view.frame.width*46/60, y: view.frame.height*16/40, width: view.frame.width/8, height: view.frame.height/6))
        syllableFour.setBackgroundImage(UIImage(named: "i"), for: .normal)
        syllableFour.addTarget(self, action: #selector(clickSyllableSix), for:.touchUpInside)
        
        syllableButton = UIButton(frame: CGRect(x: view.frame.width*7/16, y: view.frame.height*15/28, width: view.frame.width/8, height: view.frame.height/7))
        syllableButton.setBackgroundImage(UIImage(named: "startButton"), for: .normal)
        syllableButton.addTarget(self, action: #selector(clickSyllableSeven), for:.touchUpInside)
        
        syllableLastButton = UIButton(frame: CGRect(x: view.frame.width*2/9, y: view.frame.height*5/7, width: view.frame.width*2/9, height: view.frame.height/7))
        syllableLastButton.setBackgroundImage(UIImage(named: "lastButton"), for: .normal)
        syllableLastButton.addTarget(self, action: #selector(clickSyllableEight), for:.touchUpInside)
        
        syllableNextButton = UIButton(frame: CGRect(x: view.frame.width*5/9, y: view.frame.height*5/7, width: view.frame.width*2/9, height: view.frame.height/7))
        syllableNextButton.setBackgroundImage(UIImage(named: "nextButton"), for: .normal)
        syllableNextButton.addTarget(self, action: #selector(clickSyllableNine), for:.touchUpInside)
        
        syllabletrueimageView = UIImageView(frame: CGRect(x: 0, y: 0, width: 600, height: 300))
        syllabletrueimageView.center = view.center
        syllabletrueimageView.image = UIImage(named: "bingoSign")
        syllabletrueimageView.alpha = 0
        
        syllableerroimageView = UIImageView(frame: CGRect(x: 0, y: 0, width: 600, height: 300))
        syllableerroimageView.center = view.center
        syllableerroimageView.image = UIImage(named: "erroSign")
        syllableerroimageView.alpha = 0
        
        let tap = UITapGestureRecognizer(target: self, action: #selector(alphaChange))

        view.addGestureRecognizer(tap)
        
//        buttonChoose()
        self.view.addSubview(syllableBackground)
        self.view.addSubview(syllablebackButton)
//        self.view.addSubview(syllableSettingButton)
        self.view.addSubview(syllableOne)
        self.view.addSubview(syllableTwo)
        self.view.addSubview(syllableThree)
        self.view.addSubview(syllableFour)
        self.view.addSubview(syllableButton)
        self.view.addSubview(syllableLastButton)
        self.view.addSubview(syllableNextButton)
        self.view.addSubview(syllabletrueimageView)
        self.view.addSubview(syllableerroimageView)
//        buttonChoose()
        
    }
    
    func radioSyllable(name: String) {
        
        let musicUrl = NSURL(fileURLWithPath: Bundle.main.path(forResource: name, ofType: "mp3")!)
        do {
            try syllableaudioPlayer = AVAudioPlayer(contentsOf: musicUrl as URL)
            syllableaudioPlayer.prepareToPlay()
            syllableaudioPlayer.play()
            syllableaudioPlayer.numberOfLoops = 0
            syllableaudioPlayer.volume = 1
        } catch {
            print("播放错误")
        }
    }
    
    func addTap() {
        
    }
    @objc func alphaChange() {
        
        if syllabletrueimageView.alpha == 1 || syllableerroimageView.alpha == 1 {
            syllabletrueimageView.alpha = 0
            syllableerroimageView.alpha = 0
        }else {
            
            print("cuowu")
        }
            
    }
    
    @objc func clickSyllableOne() {
        
        let syllableback = ListenViewController()
        syllableback.modalPresentationStyle = .fullScreen
        self.present(syllableback, animated: true, completion: nil)
        
    }
    
//    @objc func clickSyllableTwo() {
//        
//        let listenback = TrainModViewController()
//        listenback.modalPresentationStyle = .fullScreen
//        self.present(listenback, animated: true, completion: nil)
//        
//    }
    
    @objc func clickSyllableThree() {
        //判断正确的是那个
        syllabletrueimageView.alpha = 1
        syllableerroimageView.alpha = 0
    }
    
    @objc func clickSyllableFour() {
        syllabletrueimageView.alpha = 0
        syllableerroimageView.alpha = 1
    }
    
    @objc func clickSyllableFive() {
        syllabletrueimageView.alpha = 0
        syllableerroimageView.alpha = 1
    }
    
    @objc func clickSyllableSix() {
        syllabletrueimageView.alpha = 0
        syllableerroimageView.alpha = 1
    }
    
    @objc func clickSyllableSeven() {
        
        radioSyllable(name: "7")
        
    }
    
    @objc func clickSyllableEight() {
        let syllablelast = SyllableSixViewController()
        syllablelast.modalPresentationStyle = .fullScreen
        self.present(syllablelast, animated: true, completion: nil)
    }
    
    @objc func clickSyllableNine() {
        let syllablenext = SyllableTwoViewController()
        syllablenext.modalPresentationStyle = .fullScreen
        self.present(syllablenext, animated: true, completion: nil)
    }
}
