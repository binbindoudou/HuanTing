//
//  MusicTwoViewController.swift
//  HuanTing
//
//  Created by Jung Jessica on 2022/8/31.
//

import UIKit

class MusicTwoViewController: MusicViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        super.One.setBackgroundImage(UIImage(named: "5"), for: .normal)
        view.addSubview(super.One)
        
        super.Two.setBackgroundImage(UIImage(named: "6"), for: .normal)
        view.addSubview(super.Two)
        
        super.Three.setBackgroundImage(UIImage(named: "7"), for: .normal)
        view.addSubview(super.Three)
//        Three = UIButton(frame: CGRect(x: view.frame.width*32/60, y: view.frame.height*8/40, width: view.frame.width/6, height: view.frame.height/5))
        
        super.Four.setBackgroundImage(UIImage(named: "8"), for: .normal)
        view.addSubview(super.Four)
        view.addSubview(Three)
        
//        super.Four.addTarget(self.Four, action: #selector(clickMusicSix), for: .touchUpInside)
        
        view.addSubview(musictrueimageView)
        view.addSubview(musicerroimageView)
        
    }
    
    @objc override func clickMusicThree() {
        //判断正确的是那个
        musictrueimageView.alpha = 0
        musicerroimageView.alpha = 1
    }
    
    @objc override func clickMusicFour() {
        musictrueimageView.alpha = 0
        musicerroimageView.alpha = 1
    }
    
    @objc override func clickMusicFive() {
        musictrueimageView.alpha = 0
        musicerroimageView.alpha = 1
    }
    
    @objc override func clickMusicSix() {
        musictrueimageView.alpha = 1
        musicerroimageView.alpha = 0
    }
    
    @objc override func clickMusicEight() {
        let musicnext = MusicViewController()
        musicnext.modalPresentationStyle = .fullScreen
        self.present(musicnext, animated: true, completion: nil)
    }
    
    @objc override func clickMusicNine() {
        let musiclast = MusicThreeViewController()
        musiclast.modalPresentationStyle = .fullScreen
        self.present(musiclast, animated: true, completion: nil)
    }
    
    @objc override func clickMusicSeven() {
        
        radio(name: "2")
        
    }
    
}
