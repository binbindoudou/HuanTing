//
//  MusicThreeViewController.swift
//  HuanTing
//
//  Created by Jung Jessica on 2022/8/31.
//

import UIKit

class MusicThreeViewController: MusicViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        super.One.setBackgroundImage(UIImage(named: "9"), for: .normal)
        view.addSubview(super.One)
        
        super.Two.setBackgroundImage(UIImage(named: "10"), for: .normal)
        view.addSubview(super.Two)
//        super.Two.frame(x: view.frame.width*18/60, y: view.frame.height*8/40, width: view.frame.width/6, height: view.frame.height/10)
        
//        super.Two = UIButton(frame: CGRect(x: view.frame.width*18/60, y: view.frame.height*8/40, width: view.frame.width/6, height: view.frame.height/10))
        
        super.Three.setBackgroundImage(UIImage(named: "11"), for: .normal)
        view.addSubview(super.Three)
        
        super.Four.setBackgroundImage(UIImage(named: "12"), for: .normal)
        view.addSubview(super.Four)
        
        view.addSubview(musictrueimageView)
        view.addSubview(musicerroimageView)
//        view.addSubview(Two)
        
    }
    
    @objc override func clickMusicThree() {
        //判断正确的是那个
        musictrueimageView.alpha = 0
        musicerroimageView.alpha = 1
    }
    
    @objc override func clickMusicFour() {
        musictrueimageView.alpha = 1
        musicerroimageView.alpha = 0
    }
    
    @objc override func clickMusicFive() {
        musictrueimageView.alpha = 0
        musicerroimageView.alpha = 1
    }
    
    @objc override func clickMusicSix() {
        musictrueimageView.alpha = 0
        musicerroimageView.alpha = 1
    }
    
    @objc override func clickMusicEight() {
        let musicnext = MusicTwoViewController()
        musicnext.modalPresentationStyle = .fullScreen
        self.present(musicnext, animated: true, completion: nil)
    }
    
    @objc override func clickMusicNine() {
        let musiclast = MusicFourViewController()
        musiclast.modalPresentationStyle = .fullScreen
        self.present(musiclast, animated: true, completion: nil)
    }
    
    @objc override func clickMusicSeven() {
        
        radio(name: "3")
        
    }
    
}
