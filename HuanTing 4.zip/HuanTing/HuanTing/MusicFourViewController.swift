//
//  MusicFourViewController.swift
//  HuanTing
//
//  Created by Jung Jessica on 2022/8/31.
//

import UIKit

class MusicFourViewController: MusicViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        super.One.setBackgroundImage(UIImage(named: "13"), for: .normal)
        view.addSubview(super.One)
        
        super.Two.setBackgroundImage(UIImage(named: "14"), for: .normal)
        view.addSubview(super.Two)
        
        super.Three.setBackgroundImage(UIImage(named: "15"), for: .normal)
        view.addSubview(super.Three)
        
        super.Four.setBackgroundImage(UIImage(named: "16"), for: .normal)
        view.addSubview(super.Four)
        
        view.addSubview(musictrueimageView)
        view.addSubview(musicerroimageView)
        
    }
    
    @objc override func clickMusicThree() {
        //判断正确的是那个
        musictrueimageView.alpha = 0
        musicerroimageView.alpha = 1
    }
    
    @objc override func clickMusicFour() {
        musictrueimageView.alpha = 0
        musicerroimageView.alpha = 1
    }
    
    @objc override func clickMusicFive() {
        musictrueimageView.alpha = 0
        musicerroimageView.alpha = 1
    }
    
    @objc override func clickMusicSix() {
        musictrueimageView.alpha = 1
        musicerroimageView.alpha = 0
    }
    

    @objc override func clickMusicEight() {
        let musicnext = MusicThreeViewController()
        musicnext.modalPresentationStyle = .fullScreen
        self.present(musicnext, animated: true, completion: nil)
    }
    
    @objc override func clickMusicNine() {
        let musiclast = MusicFiveViewController()
        musiclast.modalPresentationStyle = .fullScreen
        self.present(musiclast, animated: true, completion: nil)
    }

    @objc override func clickMusicSeven() {
        
        radio(name: "4")
        
    }
    
}
