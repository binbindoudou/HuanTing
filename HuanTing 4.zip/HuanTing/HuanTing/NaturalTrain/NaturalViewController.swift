//
//  NaturalViewController.swift
//  HuanTing
//
//  Created by Jung Jessica on 2022/8/30.
//

import UIKit
import AVFoundation

class NaturalViewController: UIViewController {
//    var isAlpha: Bool = false
    var naturalPlayer: AVAudioPlayer  = AVAudioPlayer()
    var naturalBackground: UIImageView!
    var naturalbackButton: UIButton!
    var naturalButton: UIButton!
//    var naturalSettingButton: UIButton!
    var naturalnextButton: UIButton!
    var naturallastButton: UIButton!
    var naturalOne: UIButton!
    var naturalTwo: UIButton!
    var naturalThree: UIButton!
    var naturalFour: UIButton!
    var trueimageView: UIImageView!
    var erroimageView: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        naturalbackButton = UIButton(frame: CGRect(x: view.frame.width/40, y: view.frame.height/26, width: view.frame.width/8, height: view.frame.height/6))
        naturalbackButton.setBackgroundImage(UIImage(named: "back"), for: .normal)
        naturalbackButton.addTarget(self, action: #selector(clickNaturalOne), for:.touchUpInside)
        
        naturalBackground = UIImageView(frame: CGRect(x: 0, y: 0, width: view.frame.width, height: view.frame.height))
        naturalBackground.image = UIImage(named: "background")
        
//        naturalSettingButton = UIButton(frame: CGRect(x: view.frame.width*7/8, y: view.frame.height/50, width: view.frame.width/8, height: view.frame.height/6))
//        naturalSettingButton.setBackgroundImage(UIImage(named: "setting"), for: .normal)
//        naturalSettingButton.addTarget(self, action: #selector(clickNaturalTwo), for:.touchUpInside)
//        naturalSettingButton.addTarget(self, action: #selector(clickNaturalTwo), for:.touchUpInside)
        
        naturalOne = UIButton(frame: CGRect(x: view.frame.width*4/60, y: view.frame.height*18/40, width: view.frame.width/6, height: view.frame.height/4))
        naturalOne.setBackgroundImage(UIImage(named: "bird"), for: .normal)
        naturalOne.addTarget(self, action: #selector(clickNaturalThree), for:.touchUpInside)
        
        naturalTwo = UIButton(frame: CGRect(x: view.frame.width*18/60, y: view.frame.height*13/40, width: view.frame.width/6, height: view.frame.height/4))
        naturalTwo.setBackgroundImage(UIImage(named: "dog"), for: .normal)
        naturalTwo.addTarget(self, action: #selector(clickNaturalFour), for:.touchUpInside)
        
        naturalThree = UIButton(frame: CGRect(x: view.frame.width*32/60, y: view.frame.height*13/40, width: view.frame.width/6, height: view.frame.height/4))
        naturalThree.setBackgroundImage(UIImage(named: "cow"), for: .normal)
        naturalThree.addTarget(self, action: #selector(clickNaturalFive), for:.touchUpInside)
        
        naturalFour = UIButton(frame: CGRect(x: view.frame.width*46/60, y: view.frame.height*18/40, width: view.frame.width/6, height: view.frame.height/4))
        naturalFour.setBackgroundImage(UIImage(named: "pig"), for: .normal)
        naturalFour.addTarget(self, action: #selector(clickNaturalSix), for:.touchUpInside)
        
        naturalButton = UIButton(frame: CGRect(x: view.frame.width*7/16, y: view.frame.height*15/28, width: view.frame.width/8, height: view.frame.height/7))
        naturalButton.setBackgroundImage(UIImage(named: "startButton"), for: .normal)
        naturalButton.addTarget(self, action: #selector(clickNaturalSeven), for:.touchUpInside)
        
        naturallastButton = UIButton(frame: CGRect(x: view.frame.width*2/9, y: view.frame.height*5/7, width: view.frame.width*2/9, height: view.frame.height/7))
        naturallastButton.setBackgroundImage(UIImage(named: "lastButton"), for: .normal)
        naturallastButton.addTarget(self, action: #selector(clickNaturalEight), for:.touchUpInside)
        
        naturalnextButton = UIButton(frame: CGRect(x: view.frame.width*5/9, y: view.frame.height*5/7, width: view.frame.width*2/9, height: view.frame.height/7))
        naturalnextButton.setBackgroundImage(UIImage(named: "nextButton"), for: .normal)
        naturalnextButton.addTarget(self, action: #selector(clickNaturalNine), for:.touchUpInside)
        
        //trueImage
        trueimageView = UIImageView(frame: CGRect(x: 0, y: 0, width: 600, height: 300))
        trueimageView.center = view.center
        trueimageView.image = UIImage(named: "bingoSign")
        trueimageView.alpha = 0
        
        erroimageView = UIImageView(frame: CGRect(x: 0, y: 0, width: 600, height: 300))
        erroimageView.center = view.center
        erroimageView.image = UIImage(named: "erroSign")
        erroimageView.alpha = 0
        
        let tap = UITapGestureRecognizer(target: self, action: #selector(alphaChange))
        
//        let tapped = UITapGestureRecognizer(target: self, action: #selector(alphaChangeTwo))

        view.addGestureRecognizer(tap)
//        view.addGestureRecognizer(tapped)
        
        
//        buttonChoose()
        self.view.addSubview(naturalBackground)
        self.view.addSubview(naturalbackButton)
//        self.view.addSubview(naturalSettingButton)
        self.view.addSubview(naturalOne)
        self.view.addSubview(naturalTwo)
        self.view.addSubview(naturalThree)
        self.view.addSubview(naturalFour)
        self.view.addSubview(naturalButton)
        self.view.addSubview(naturallastButton)
        self.view.addSubview(naturalnextButton)
        self.view.addSubview(trueimageView)
        self.view.addSubview(erroimageView)
//        buttonChoose()
    }
    
    func radioNatural(name: String) {
        
        let musicUrl = NSURL(fileURLWithPath: Bundle.main.path(forResource: name, ofType: "mp3")!)
        do {
            try naturalPlayer = AVAudioPlayer(contentsOf: musicUrl as URL)
            naturalPlayer.prepareToPlay()
            naturalPlayer.play()
            naturalPlayer.numberOfLoops = 0
            naturalPlayer.volume = 1
        } catch {
            print("播放错误")
        }
    }
    
    func addTap() {
        
    }
    
    
    @objc func alphaChange() {
        if trueimageView.alpha == 1 || erroimageView.alpha == 1 {
            trueimageView.alpha = 0
            erroimageView.alpha = 0
//            erroimageView.alpha = 1
        } else {
            print("cuowu")
        }
            
    }
    
//    @objc func alphaChangeTwo() {
//        if erroimageView.alpha == 1 {
//            erroimageView.alpha = 0
//        } else {
//            print("cuowu")
//        }
//
//    }
    
    @objc func clickNaturalOne() {
        
        let naturalback = ListenViewController()
        naturalback.modalPresentationStyle = .fullScreen
        self.present(naturalback, animated: true, completion: nil)
        
    }
    
//    @objc func clickNaturalTwo() {
//
//        let naturalSetting = TrainModViewController()
//        naturalSetting.modalPresentationStyle = .fullScreen
//        self.present(naturalSetting, animated: true, completion: nil)
//
//    }
    
    @objc func clickNaturalThree() {
        //判断正确的是那个
        
        trueimageView.alpha = 1
        erroimageView.alpha = 0
        
    }
    
    @objc func clickNaturalFour() {
        trueimageView.alpha = 0
        erroimageView.alpha = 1
    }
    
    @objc func clickNaturalFive() {
        trueimageView.alpha = 0
        erroimageView.alpha = 1
    }
    
    @objc func clickNaturalSix() {
        trueimageView.alpha = 0
        erroimageView.alpha = 1
    }
    
    @objc func clickNaturalSeven() {
        radioNatural(name: "13")
    }
    
    @objc func clickNaturalEight() {
        let naturallast = NaturalSixViewController()
        naturallast.modalPresentationStyle = .fullScreen
        self.present(naturallast, animated: true, completion: nil)
    }
    
    @objc func clickNaturalNine() {
        let naturalnext = NaturalTwoViewController()
        naturalnext.modalPresentationStyle = .fullScreen
        self.present(naturalnext, animated: true, completion: nil)
    }
    

}



