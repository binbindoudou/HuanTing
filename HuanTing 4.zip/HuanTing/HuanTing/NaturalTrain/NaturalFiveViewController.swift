//
//  NaturalFiveViewController.swift
//  HuanTing
//
//  Created by Jung Jessica on 2022/8/31.
//

import UIKit

class NaturalFiveViewController: NaturalViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        super.naturalOne.setBackgroundImage(UIImage(named: "zouLu"), for: .normal)
        view.addSubview(super.naturalOne)
        
        super.naturalTwo.setBackgroundImage(UIImage(named: "diShui"), for: .normal)
        view.addSubview(super.naturalTwo)
        
        super.naturalThree.setBackgroundImage(UIImage(named: "caiBan"), for: .normal)
        view.addSubview(super.naturalThree)
        
        super.naturalFour.setBackgroundImage(UIImage(named: "knockDoor"), for: .normal)
        view.addSubview(super.naturalFour)
        
        view.addSubview(trueimageView)
        view.addSubview(erroimageView)
        
    }
    
    @objc override func clickNaturalThree() {
        //判断正确的是那个
        trueimageView.alpha = 0
        erroimageView.alpha = 1
    }
    
    @objc override func clickNaturalFour() {
        trueimageView.alpha = 0
        erroimageView.alpha = 1
    }
    
    @objc override func clickNaturalFive() {
        trueimageView.alpha = 1
        erroimageView.alpha = 0
    }
    
    @objc override func clickNaturalSix() {
        trueimageView.alpha = 0
        erroimageView.alpha = 1
    }
    
    @objc override func clickNaturalEight() {
        let naturallast = NaturalFourViewController()
        naturallast.modalPresentationStyle = .fullScreen
        self.present(naturallast, animated: true, completion: nil)
    }
    
    @objc override func clickNaturalNine() {
        let naturalnext = NaturalSixViewController()
        naturalnext.modalPresentationStyle = .fullScreen
        self.present(naturalnext, animated: true, completion: nil)
    }
    
    @objc override func clickNaturalSeven() {
        radioNatural(name: "17")
    }
    
}
