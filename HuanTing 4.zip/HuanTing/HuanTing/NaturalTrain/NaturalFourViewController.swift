//
//  NaturalFourViewController.swift
//  HuanTing
//
//  Created by Jung Jessica on 2022/8/31.
//

import UIKit

class NaturalFourViewController: NaturalViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        super.naturalOne.setBackgroundImage(UIImage(named: "sheep"), for: .normal)
        view.addSubview(super.naturalOne)
        
        super.naturalTwo.setBackgroundImage(UIImage(named: "cat"), for: .normal)
        view.addSubview(super.naturalTwo)
        
        super.naturalThree.setBackgroundImage(UIImage(named: "chan"), for: .normal)
        view.addSubview(super.naturalThree)
        
        super.naturalFour.setBackgroundImage(UIImage(named: "niu"), for: .normal)
        view.addSubview(super.naturalFour)
        
        view.addSubview(trueimageView)
        view.addSubview(erroimageView)
        
    }
    
    @objc override func clickNaturalThree() {
        //判断正确的是那个
        trueimageView.alpha = 0
        erroimageView.alpha = 1
    }
    
    @objc override func clickNaturalFour() {
        trueimageView.alpha = 0
        erroimageView.alpha = 1
    }
    
    @objc override func clickNaturalFive() {
        trueimageView.alpha = 0
        erroimageView.alpha = 1
    }
    
    @objc override func clickNaturalSix() {
        trueimageView.alpha = 1
        erroimageView.alpha = 0
    }
    
    
    @objc override func clickNaturalEight() {
        let naturallast = NaturalThreeViewController()
        naturallast.modalPresentationStyle = .fullScreen
        self.present(naturallast, animated: true, completion: nil)
    }
    
    @objc override func clickNaturalNine() {
        let naturalnext = NaturalFiveViewController()
        naturalnext.modalPresentationStyle = .fullScreen
        self.present(naturalnext, animated: true, completion: nil)
    }
    
    @objc override func clickNaturalSeven() {
        radioNatural(name: "16")
    }
    
}
