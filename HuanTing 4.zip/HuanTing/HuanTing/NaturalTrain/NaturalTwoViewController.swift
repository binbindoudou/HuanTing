//
//  NaturalTwoViewController.swift
//  HuanTing
//
//  Created by Jung Jessica on 2022/8/31.
//

import UIKit

class NaturalTwoViewController: NaturalViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        super.naturalOne.setBackgroundImage(UIImage(named: "guitar"), for: .normal)
        view.addSubview(super.naturalOne)
        
        super.naturalTwo.setBackgroundImage(UIImage(named: "piano"), for: .normal)
        view.addSubview(super.naturalTwo)
        
        super.naturalThree.setBackgroundImage(UIImage(named: "drum"), for: .normal)
        view.addSubview(super.naturalThree)
        
        super.naturalFour.setBackgroundImage(UIImage(named: "violin"), for: .normal)
        view.addSubview(super.naturalFour)
        
//        super.naturalOne.removeTarget(self, action: #selector(clickNaturalThree), for: .touchUpInside)
//      
//        super.naturalFour.addTarget(self.naturalFour, action: #selector(clickNaturalSix), for: .touchUpInside)
        
//        super.NaturalEight.addTarget(self.natural, action: #selector(clickNaturalNine), for: .touchUpInside)
        super.naturallastButton.addTarget(self, action: #selector(clickNaturalEight), for: .touchUpInside)
        super.naturalnextButton.addTarget(self, action: #selector(clickNaturalNine), for: .touchUpInside)
        view.addSubview(trueimageView)
        view.addSubview(erroimageView)
        
    }
    
    @objc override func clickNaturalThree() {
        //判断正确的是那个
        trueimageView.alpha = 0
        erroimageView.alpha = 1
    }
    
    @objc override func clickNaturalFour() {
        trueimageView.alpha = 0
        erroimageView.alpha = 1
    }
    
    @objc override func clickNaturalFive() {
        trueimageView.alpha = 0
        erroimageView.alpha = 1
    }
    
    @objc override func clickNaturalSix() {
        trueimageView.alpha = 1
        erroimageView.alpha = 0
    }
    
    
    @objc override func clickNaturalEight() {
        let naturallast = NaturalViewController()
        naturallast.modalPresentationStyle = .fullScreen
        self.present(naturallast, animated: true, completion: nil)
    }
    
    @objc override func clickNaturalNine() {
        let naturalnext = NaturalThreeViewController()
        naturalnext.modalPresentationStyle = .fullScreen
        self.present(naturalnext, animated: true, completion: nil)
    }
    
    @objc override func clickNaturalSeven() {
        radioNatural(name: "14")
    }
    
}
