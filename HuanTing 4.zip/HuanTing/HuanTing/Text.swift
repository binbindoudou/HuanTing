//
//  Text.swift
//  HuanTing
//
//  Created by Jung Jessica on 2022/9/2.
//

import SwiftUI
import

struct Text: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct Text_Previews: PreviewProvider {
    static var previews: some View {
        Text()
    }
}
