//
//  SyllableFourViewController.swift
//  HuanTing
//
//  Created by Jung Jessica on 2022/8/31.
//

import UIKit

class SyllableFourViewController: SyllableViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        super.syllableOne.setBackgroundImage(UIImage(named: "b"), for: .normal)
        view.addSubview(super.syllableOne)
        
        super.syllableTwo.setBackgroundImage(UIImage(named: "p"), for: .normal)
        view.addSubview(super.syllableTwo)
        
        super.syllableThree.setBackgroundImage(UIImage(named: "m"), for: .normal)
        view.addSubview(super.syllableThree)
        
        super.syllableFour.setBackgroundImage(UIImage(named: "f"), for: .normal)
        view.addSubview(super.syllableFour)
    
        view.addSubview(syllabletrueimageView)
        view.addSubview(syllableerroimageView)
        
        
    }
    @objc override func clickSyllableThree() {
        //判断正确的是那个
        syllabletrueimageView.alpha = 0
        syllableerroimageView.alpha = 1
    }
    
    @objc override func clickSyllableFour() {
        syllabletrueimageView.alpha = 0
        syllableerroimageView.alpha = 1
    }
    
    @objc override func clickSyllableFive() {
        syllabletrueimageView.alpha = 0
        syllableerroimageView.alpha = 1
    }
    
    @objc override func clickSyllableSix() {
        syllabletrueimageView.alpha = 1
        syllableerroimageView.alpha = 0
    }
    
    @objc override func clickSyllableEight() {
        let syllablelast = SyllableThreeViewController()
        syllablelast.modalPresentationStyle = .fullScreen
        self.present(syllablelast, animated: true, completion: nil)
    }
    
    @objc override func clickSyllableNine() {
        let syllablenext = SyllableFiveViewController()
        syllablenext.modalPresentationStyle = .fullScreen
        self.present(syllablenext, animated: true, completion: nil)
    }

    @objc override func clickSyllableSeven() {
        
        radioSyllable(name: "10")
        
    }

}
