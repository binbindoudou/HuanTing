//
//  ViewController.swift
//  HuanTing
//
//  Created by 肖俊生 on 2022/8/30.
//

import UIKit

class ViewController: UIViewController {
    
    var backgroungImage: UIImageView!
    var titleImage: UIImageView!
    var actionButton: UIButton!
//    var settingButton: UIButton!

    override func viewDidLoad() {
        super.viewDidLoad()
        
        backgroungImage = UIImageView(frame: CGRect(x: 0, y: 0, width: view.frame.width, height: view.frame.height))
        backgroungImage.image = UIImage(named: "background")
        
        titleImage = UIImageView(frame: CGRect(x: 0, y: 0, width: view.frame.width, height: view.frame.height))
        titleImage.image = UIImage(named: "title")
        
        actionButton = UIButton(frame: CGRect(x: view.frame.width*7/24, y: view.frame.height*5/8, width: view.frame.width*5/12, height: view.frame.height/4))
        actionButton.setBackgroundImage(UIImage(named: "actionButton"), for: .normal)
        actionButton.addTarget(self, action: #selector(clickOne), for:.touchUpInside)
        
//        settingButton = UIButton(frame: CGRect(x: view.frame.width*7/8, y: view.frame.height/50, width: view.frame.width/8, height: view.frame.height/6))
//        settingButton.setBackgroundImage(UIImage(named: "setting"), for: .normal)
//        settingButton.addTarget(self, action: #selector(clickTwo), for:.touchUpInside)
        
        self.view.addSubview(backgroungImage)
        self.view.addSubview(titleImage)
        self.view.addSubview(actionButton)
//        self.view.addSubview(settingButton)
        
    }

    @objc func clickOne() {
        
        let second = TrainModViewController()
        second.modalPresentationStyle = .fullScreen
        self.present(second, animated: true, completion: nil)
        
    }
    


}

