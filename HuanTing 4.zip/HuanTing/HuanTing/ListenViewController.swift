//
//  LIstenViewController.swift
//  HuanTing
//
//  Created by Jung Jessica on 2022/8/30.
//

import UIKit

public class ListenViewController: UIViewController {
    
    
    let startTime = CFAbsoluteTimeGetCurrent()
    let endTime = CFAbsoluteTimeGetCurrent()
    
    var listenViewBackground: UIImageView!
    var listenSign: UIImageView!
    var listenbackButton: UIButton!
    var naturalButton: UIButton!
    var syllableButton: UIButton!
    var musicButton: UIButton!
//    var naturalPlaying: Bool = false
//    var syllablePlaying: Bool = false
//    var musicPlaying: Bool = false
//    var count = 0.0
//    var naturalTimer = Timer()
//    var naturalTimeLabel: UILabel!
//    var naturalbackButton: UIButton!
    
    
    
    public override func viewDidLoad() {
        super.viewDidLoad()

        listenbackButton = UIButton(frame: CGRect(x: view.frame.width/40, y: view.frame.height/26, width: view.frame.width/8, height: view.frame.height/6))
        listenbackButton.setBackgroundImage(UIImage(named: "back"), for: .normal)
        listenbackButton.addTarget(self, action: #selector(clickListenOne), for:.touchUpInside)
        
        listenViewBackground = UIImageView(frame: CGRect(x: 0, y: 0, width: view.frame.width, height: view.frame.height))
        listenViewBackground.image = UIImage(named: "background")
        
        listenSign = UIImageView(frame: CGRect(x: view.frame.width/10, y: view.frame.height/4, width: view.frame.width/4, height: view.frame.height*3/5))
        listenSign.image = UIImage(named: "listenButton")
        
        naturalButton = UIButton(frame: CGRect(x: view.frame.width*7/20, y: view.frame.height*3/20, width: view.frame.width*5/10, height: view.frame.height/5))
        naturalButton.setBackgroundImage(UIImage(named: "natural"), for: .normal)
        naturalButton.addTarget(self, action: #selector(clickListenTwo), for:.touchUpInside)
        
        syllableButton = UIButton(frame: CGRect(x: view.frame.width*7/20, y: view.frame.height*8/20, width: view.frame.width*5/10, height: view.frame.height/5))
        syllableButton.setBackgroundImage(UIImage(named: "syllable"), for: .normal)
        syllableButton.addTarget(self, action: #selector(clickListenThree), for:.touchUpInside)
        
        musicButton = UIButton(frame: CGRect(x: view.frame.width*7/20, y: view.frame.height*13/20, width: view.frame.width*5/10, height: view.frame.height/5))
        musicButton.setBackgroundImage(UIImage(named: "music"), for: .normal)
        musicButton.addTarget(self, action: #selector(clickListenFour), for:.touchUpInside)
        
//        naturalTimeLabel = UILabel(frame: CGRect(x: 0, y: 0, width: view.frame.width, height: view.frame.height))
//        naturalTimeLabel.text = String(count)
//        naturalbackButton = UIButton(frame: CGRect(x: 0, y: 0, width: 0, height: 0))
//        naturalbackButton.isEnabled = false
        
        self.view.addSubview(listenViewBackground)
        self.view.addSubview(listenbackButton)
        self.view.addSubview(listenSign)
        self.view.addSubview(naturalButton)
        self.view.addSubview(syllableButton)
        self.view.addSubview(musicButton)
//        self.view.addSubview(naturalTimeLabel)
//        self.view.addSubview(naturalbackButton)
        
        debugPrint("代码执行时长：%f 毫秒", (endTime - startTime)*1000)
    }
    
//    func naturalStartTimer(_ sender: AnyObject) {
//        if (naturalPlaying) {
//            return
//        }
//        naturalButton.isEnabled = false
//        syllableButton.isEnabled = true
//        naturalTimer = Timer.scheduledTimer(timeInterval: 0.1, target: self, selector: #selector(UpdateNaturalTimer), userInfo: nil, repeats: true)
//        naturalPlaying = true
//        print(count)
//    }
//
//    func naturalPauseTimer(_ sender: AnyObject) {
//        naturalButton.isEnabled = true
//        syllableButton.isEnabled = false
//
//        naturalTimer.invalidate()
//        musicPlaying = false
//        print(count)
//    }
//
//    @objc func UpdateNaturalTimer() {
//
//        count = count + 0.1
//        naturalTimeLabel.text = String(format: "%.1f", count)
//
//    }
//
    @objc func clickListenOne() {
        
        let listenback = TrainModViewController()
        listenback.modalPresentationStyle = .fullScreen
        self.present(listenback, animated: true, completion: nil)
        
    }
    
    @objc func clickListenTwo() {
        
        let natural = NaturalViewController()
        natural.modalPresentationStyle = .fullScreen
        self.present(natural, animated: true, completion: nil)
        
    }
    
    @objc func clickListenThree() {
        
        let syllable = SyllableViewController()
        syllable.modalPresentationStyle = .fullScreen
        self.present(syllable, animated: true, completion: nil)
        
    }
    
    @objc func clickListenFour() {
        
        let music = MusicViewController()
        music.modalPresentationStyle = .fullScreen
        self.present(music, animated: true, completion: nil)
        
    }
    
    

}
