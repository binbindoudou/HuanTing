//
//  Testing.swift
//  HuanTing
//
//  Created by Jung Jessica on 2022/8/31.
//

import Foundation
import UIKit

class BasicVc: UIViewController {
    var imageVC = UIImageView()
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
    }
    
    func setupUI(){
        imageVC.frame = view.frame
        imageVC.image = UIImage(named: "background")
        view.addSubview(imageVC)
    }
}
