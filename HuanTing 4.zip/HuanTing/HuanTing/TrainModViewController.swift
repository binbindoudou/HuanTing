//
//  TrainModViewController.swift
//  HuanTing
//
//  Created by Jung Jessica on 2022/8/30.
//

import UIKit

class TrainModViewController: UIViewController {
    
    var trainModImage: UIImageView!
    var buttonOne: UIButton!
    var buttonTwo: UIButton!
    var buttonThree: UIButton!
    var backButton:UIButton!

    override func viewDidLoad() {
        super.viewDidLoad()
        
        trainModImage = UIImageView(frame: CGRect(x: 0, y: 0, width: view.frame.width, height: view.frame.height))
        trainModImage.image = UIImage(named: "background")
        
        backButton = UIButton(frame: CGRect(x: view.frame.width/40, y: view.frame.height/26, width: view.frame.width/8, height: view.frame.height/6))
        backButton.setBackgroundImage(UIImage(named: "back"), for: .normal)
        backButton.addTarget(self, action: #selector(clickTrainOne), for:.touchUpInside)
        
//        buttonOne = UIButton(frame: CGRect(x: view.frame.width*6/40, y: view.frame.height/5, width: view.frame.width*11/40, height: view.frame.height*2/3))
//        buttonOne.setBackgroundImage(UIImage(named: "listenButton"), for: .normal)
//        buttonOne.addTarget(self, action: #selector(clickTrainTwo), for:.touchUpInside)
        
        buttonOne = UIButton(frame: CGRect(x: view.frame.width*2/40, y: view.frame.height/5, width: view.frame.width*11/40, height: view.frame.height*2/3))
        buttonOne.setBackgroundImage(UIImage(named: "listenButton"), for: .normal)
        buttonOne.addTarget(self, action: #selector(clickTrainTwo), for:.touchUpInside)
        
        buttonTwo = UIButton(frame: CGRect(x: view.frame.width*29/80, y: view.frame.height/5, width: view.frame.width*11/40, height: view.frame.height*2/3))
        buttonTwo.setBackgroundImage(UIImage(named: "speakButton"), for: .normal)
        buttonTwo.addTarget(self, action: #selector(clickTrainThree), for:.touchUpInside)
        
//        buttonTwo = UIButton(frame: CGRect(x: view.frame.width*23/40, y: view.frame.height/5, width: view.frame.width*11/40, height: view.frame.height*2/3))
//        buttonTwo.setBackgroundImage(UIImage(named: "speakButton"), for: .normal)
//        buttonTwo.addTarget(self, action: #selector(clickTrainThree), for:.touchUpInside)
        
        buttonThree = UIButton(frame: CGRect(x: view.frame.width*27/40, y: view.frame.height/5, width: view.frame.width*11/40, height: view.frame.height*2/3))
        buttonThree.setBackgroundImage(UIImage(named: "personalCenter"), for: .normal)
        buttonThree.addTarget(self, action: #selector(clickTrainFour), for:.touchUpInside)
        
        self.view.addSubview(trainModImage)
        self.view.addSubview(backButton)
        self.view.addSubview(buttonOne)
        self.view.addSubview(buttonTwo)
        self.view.addSubview(buttonThree)

        // Do any additional setup after loading the view.
    }
    
    @objc func clickTrainOne() {
        
        let back = ViewController()
        back.modalPresentationStyle = .fullScreen
        self.present(back, animated: true, completion: nil)
        
    }
    
    @objc func clickTrainTwo() {
        
        let listen = ListenViewController()
        listen.modalPresentationStyle = .fullScreen
        self.present(listen, animated: true, completion: nil)
        
    }
    
    @objc func clickTrainThree() {
        
        let speak = SpeakViewController()
        speak.modalPresentationStyle = .fullScreen
        self.present(speak, animated: true, completion: nil)
        
    }
    
    @objc func clickTrainFour() {

        let person = PersonalViewController()
        person.modalPresentationStyle = .fullScreen
        self.present(person, animated: true, completion: nil)

    }

}
