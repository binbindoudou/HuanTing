//
//  poetryViewController.swift
//  HuanTing
//
//  Created by Jung Jessica on 2022/8/30.
//

//import UIKit
//import Speech
//
//class PoetryViewController: UIViewController, SFSpeechRecognizerDelegate {
//
//    @IBOutlet weak var textView: UITextView!
//    @IBOutlet weak var microphoneButton: UIButton!
//
//    private let speechRecognizer = SFSpeechRecognizer(locale: Locale.init(identifier: "zh-CS"))!
//
//    override func viewDidLoad() {
//
//        super.viewDidLoad()
//
////        microphoneButton.isEnabled = false
//
//        speechRecognizer.delegate = self
//
//
//        SFSpeechRecognizer.requestAuthorization { (authStatus) in
//
//            var isButtonEnabled = false
//
//            switch authStatus {
//
//            case .authorized:
//                isButtonEnabled = true
//
//            case .denied:
//                isButtonEnabled = false
//                print("用户拒绝访问语音访问")
//
//            case .restricted:
//                isButtonEnabled = false
//                print("此设备不支持语音识别")
//
//            case .notDetermined:
//                isButtonEnabled = false
//                print("语音功能未授权")
//
//            }
//
//            OperationQueue.main.addOperation {
//
//                self.microphoneButton.isEnabled = isButtonEnabled
//
//            }
//
//        }
//
//
//    }
//
//    @IBAction func microphoneTapped(_ sender: AnyObject) {
//
//    }
//
//}

import UIKit
import Speech

public class PoertyViewController: UIViewController, SFSpeechRecognizerDelegate {
    // MARK: Properties
    var change = 1
    var poertyBackground: UIImageView!
    var poetrybackButton: UIButton!
    var recordButton: UIButton!
    var textView: UITextView!
    var pomImage: UIImageView!
    var isSpeak: Bool = false
    var image1: UIImageView!
    var image2: UIImageView!
    var image3: UIImageView!
    var image4: UIImageView!
    var image5: UIImageView!
    var image6: UIImageView!
    var image7: UIImageView!
    var image8: UIImageView!
    var image9: UIImageView!
    var image10: UIImageView!
    var image21: UIImageView!
    var image22: UIImageView!
    var image23: UIImageView!
    var image24: UIImageView!
    var image25: UIImageView!
    var image26: UIImageView!
    var image27: UIImageView!
    var image31: UIImageView!
    var image32: UIImageView!
    var image33: UIImageView!
    var image34: UIImageView!
    var image35: UIImageView!
    var image36: UIImageView!
    var image37: UIImageView!
    var bingoView: UIImageView!
    var bingoViewTwo: UIImageView!
    var bingoViewThree: UIImageView!
//    var judge: Bool = false
    
    private let speechRecognizer = SFSpeechRecognizer(locale: Locale(identifier: "zh-CN"))!
    
    private var recognitionRequest: SFSpeechAudioBufferRecognitionRequest?
    
    private var recognitionTask: SFSpeechRecognitionTask?
    
    private let audioEngine = AVAudioEngine()
    
    //    @IBOutlet var textView: UITextView!
    
    //    @IBOutlet var recordButton: UIButton!
    
    // MARK: View Controller Lifecycle
    
    public override func viewDidLoad() {
        super.viewDidLoad()
        
        poertyBackground = UIImageView(frame: CGRect(x: 0, y: 0, width: view.frame.width, height: view.frame.height))
        poertyBackground.image = UIImage(named: "backgroundBlue")
        
        poetrybackButton = UIButton(frame: CGRect(x: view.frame.width/40, y: view.frame.height/26, width: view.frame.width/8, height: view.frame.height/6))
        poetrybackButton.setBackgroundImage(UIImage(named: "back"), for: .normal)
        poetrybackButton.addTarget(self, action: #selector(clickPoetryOne), for:.touchUpInside)
        
        recordButton = UIButton(frame: CGRect(x: view.frame.width*8/20, y: view.frame.height*24/30, width: view.frame.width*4/20, height: view.frame.height*4/30))
        recordButton.setBackgroundImage(UIImage(named: "readAction"), for: .normal)
        recordButton.addTarget(self, action: #selector(clickPoetryTwo), for: .touchUpInside)
        
        textView = UITextView(frame: CGRect(x: view.frame.width*3/8, y: view.frame.height/6, width: view.frame.width/4, height: view.frame.height*2/3))
        
        //        pomImage = UIImageView(frame: CGRect(x: view.frame.width*2/18, y: view.frame.height/6, width: view.frame.width/3, height: view.frame.height*2/3))
        //        pomImage.image = UIImage(named: "pomWord")
        //        textView.largeContentImage = UIImage(named: "backgroundBlueTwo")
        image1 = UIImageView(frame: CGRect(x: view.frame.width*9/60, y: view.frame.height*5/24, width: view.frame.width/15, height: view.frame.height*4/24))
        image1.image = UIImage(named: "w1")
        
        image2 = UIImageView(frame: CGRect(x: view.frame.width*14/60, y: view.frame.height*5/24, width: view.frame.width/20, height: view.frame.height*4/24))
        image2.image = UIImage(named: "w2")
        
        image3 = UIImageView(frame: CGRect(x: view.frame.width*7/24, y: view.frame.height*5/24, width: view.frame.width/15, height: view.frame.height*4/24))
        image3.image = UIImage(named: "w3")
        
        image4 = UIImageView(frame: CGRect(x: view.frame.width*9/24, y: view.frame.height*5/24, width: view.frame.width/20, height: view.frame.height*4/24))
        image4.image = UIImage(named: "w4")
        
        image5 = UIImageView(frame: CGRect(x: view.frame.width*13/30, y: view.frame.height*5/24, width: view.frame.width/13, height: view.frame.height*4/24))
        image5.image = UIImage(named: "w5")
        
        image6 = UIImageView(frame: CGRect(x: view.frame.width*61/120, y: view.frame.height*5/24, width: view.frame.width/15, height: view.frame.height*4/24))
        image6.image = UIImage(named: "w6")
        
        image7 = UIImageView(frame: CGRect(x: view.frame.width*35/60, y: view.frame.height*5/24, width: view.frame.width/15, height: view.frame.height*4/24))
        image7.image = UIImage(named: "w7")
        
        image8 = UIImageView(frame: CGRect(x: view.frame.width*39/60, y: view.frame.height*5/24, width: view.frame.width/15, height: view.frame.height*4/24))
        image8.image = UIImage(named: "w8")
        
        image9 = UIImageView(frame: CGRect(x: view.frame.width*87/120, y: view.frame.height*5/24, width: view.frame.width/20, height: view.frame.height*4/24))
        image9.image = UIImage(named: "w9")
        
        image10 = UIImageView(frame: CGRect(x: view.frame.width*47/60, y: view.frame.height*5/24, width: view.frame.width/10, height: view.frame.height*4/24))
        image10.image = UIImage(named: "w10")
        
        bingoView = UIImageView(frame: CGRect(x: view.frame.width*54/60, y: view.frame.height*6/24, width: view.frame.width/12, height: view.frame.height*3/24))
        bingoView.image = UIImage(named: "bingo")
        bingoView.alpha = 0
        
        image21 = UIImageView(frame: CGRect(x: view.frame.width*9/60, y: view.frame.height*19/48, width: view.frame.width/15, height: view.frame.height*7/48))
        image21.image = UIImage(named: "w21")
        
        image22 = UIImageView(frame: CGRect(x: view.frame.width*14/60, y: view.frame.height*19/48, width: view.frame.width*4/60, height: view.frame.height*7/48))
        image22.image = UIImage(named: "w22")
        
        image23 = UIImageView(frame: CGRect(x: view.frame.width*19/60, y: view.frame.height*19/48, width: view.frame.width/15, height: view.frame.height*7/48))
        image23.image = UIImage(named: "w23")
        
        image24 = UIImageView(frame: CGRect(x: view.frame.width*24/60, y: view.frame.height*19/48, width: view.frame.width/15, height: view.frame.height*7/48))
        image24.image = UIImage(named: "w24")
        
        image25 = UIImageView(frame: CGRect(x: view.frame.width*29/60, y: view.frame.height*19/48, width: view.frame.width/13, height: view.frame.height*7/48))
        image25.image = UIImage(named: "w25")
        
        image26 = UIImageView(frame: CGRect(x: view.frame.width*34/60, y: view.frame.height*19/48, width: view.frame.width/15, height: view.frame.height*7/48))
        image26.image = UIImage(named: "w26")
        
        image27 = UIImageView(frame: CGRect(x: view.frame.width*39/60, y: view.frame.height*19/48, width: view.frame.width*11/120, height: view.frame.height*5/32))
        image27.image = UIImage(named: "w27")
        
        bingoViewTwo = UIImageView(frame: CGRect(x: view.frame.width*46/60, y: view.frame.height*20/48, width: view.frame.width*9/120, height: view.frame.height*3/32))
        bingoViewTwo.image = UIImage(named: "bingo")
        bingoViewTwo.alpha = 0
        
        image31 = UIImageView(frame: CGRect(x: view.frame.width*9/60, y: view.frame.height*55/96, width: view.frame.width/15, height: view.frame.height*7/48))
        image31.image = UIImage(named: "w31")
        
        image32 = UIImageView(frame: CGRect(x: view.frame.width*14/60, y: view.frame.height*55/96, width: view.frame.width/15, height: view.frame.height*7/48))
        image32.image = UIImage(named: "w32")
        
        image33 = UIImageView(frame: CGRect(x: view.frame.width*19/60, y: view.frame.height*55/96, width: view.frame.width/15, height: view.frame.height*4/24))
        image33.image = UIImage(named: "w33")
        
        image34 = UIImageView(frame: CGRect(x: view.frame.width*24/60, y: view.frame.height*55/96, width: view.frame.width/20, height: view.frame.height*4/24))
        image34.image = UIImage(named: "w34")
        
        image35 = UIImageView(frame: CGRect(x: view.frame.width*57/120, y: view.frame.height*55/96, width: view.frame.width/15, height: view.frame.height*4/24))
        image35.image = UIImage(named: "w35")
        
        image36 = UIImageView(frame: CGRect(x: view.frame.width*34/60, y: view.frame.height*55/96, width: view.frame.width/15, height: view.frame.height*7/48))
        image36.image = UIImage(named: "w36")
        
        image37 = UIImageView(frame: CGRect(x: view.frame.width*39/60, y: view.frame.height*55/96, width: view.frame.width/10, height: view.frame.height*4/24))
        image37.image = UIImage(named: "w37")
        
        bingoViewThree = UIImageView(frame: CGRect(x: view.frame.width*46/60, y: view.frame.height*58/96, width: view.frame.width/12, height: view.frame.height*3/24))
        bingoViewThree.image = UIImage(named: "bingo")
        bingoViewThree.alpha = 0
        
        
        
        //        self.view.addSubview(poertyBackground)
        self.view.addSubview(textView)
        self.view.addSubview(poertyBackground)
        self.view.addSubview(poetrybackButton)
        self.view.addSubview(recordButton)
        //        self.view.addSubview(textView)
        //        self.view.addSubview(pomImage)
        self.view.addSubview(image1)
        self.view.addSubview(image2)
        self.view.addSubview(image3)
        self.view.addSubview(image4)
        self.view.addSubview(image5)
        self.view.addSubview(image6)
        self.view.addSubview(image7)
        self.view.addSubview(image8)
        self.view.addSubview(image9)
        self.view.addSubview(image10)
        self.view.addSubview(image21)
        self.view.addSubview(image22)
        self.view.addSubview(image23)
        self.view.addSubview(image24)
        self.view.addSubview(image25)
        self.view.addSubview(image26)
        self.view.addSubview(image27)
        self.view.addSubview(image31)
        self.view.addSubview(image32)
        self.view.addSubview(image33)
        self.view.addSubview(image34)
        self.view.addSubview(image35)
        self.view.addSubview(image36)
        self.view.addSubview(image37)
        self.view.addSubview(bingoView)
        self.view.addSubview(bingoViewTwo)
        self.view.addSubview(bingoViewThree)
        
    }
    
    override public func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        // Configure the SFSpeechRecognizer object already
        // stored in a local member variable.
        speechRecognizer.delegate = self
        
        // Asynchronously make the authorization request.
        SFSpeechRecognizer.requestAuthorization { authStatus in
            
            // Divert to the app's main thread so that the UI
            // can be updated.
            OperationQueue.main.addOperation {
                switch authStatus {
                case .authorized:
                    self.recordButton.isEnabled = true
                    
                case .denied:
                    self.recordButton.isEnabled = false
                    self.recordButton.setTitle("用户拒绝访问语音", for: .disabled)
                    
                case .restricted:
                    self.recordButton.isEnabled = false
                    self.recordButton.setTitle("此设备限制语音识别", for: .disabled)
                    
                case .notDetermined:
                    self.recordButton.isEnabled = false
                    self.recordButton.setTitle("Speech recognition not yet authorized", for: .disabled)
                    
                default:
                    self.recordButton.isEnabled = false
                }
            }
        }
    }
    
    @objc func clickPoetryOne() {
        
        let poetryback = SpeakViewController()
        poetryback.modalPresentationStyle = .fullScreen
        self.present(poetryback, animated: true, completion: nil)
        
    }
    
    @objc func clickPoetryTwo() {
        //        print("123")
        //        speechRecognizer
        //        change += 1
        //
        //        if change % 2 == 0 {
        //            recordButton.setBackgroundImage(UIImage(named: "readAction"), for: .normal)
        //        } else {
        //            recordButton.setBackgroundImage(UIImage(named: "readStop"), for: .normal)
        //
        //        }
        
        if isSpeak {
            
            recordButton.setBackgroundImage(UIImage(named: "readAction"), for: .normal)
            isSpeak = false
            recordButtonTapped()
            
            
            
            image1.image = UIImage(named: "w1")
            image2.image = UIImage(named: "w2")
            image3.image = UIImage(named: "w3")
            image4.image = UIImage(named: "w4")
            image5.image = UIImage(named: "w5")
            image6.image = UIImage(named: "w6")
            image7.image = UIImage(named: "w7")
            image8.image = UIImage(named: "w8")
            image9.image = UIImage(named: "w9")
            image10.image = UIImage(named: "w10")
            image21.image = UIImage(named: "w21")
            image22.image = UIImage(named: "w22")
            image23.image = UIImage(named: "w23")
            image24.image = UIImage(named: "w24")
            image25.image = UIImage(named: "w25")
            image26.image = UIImage(named: "w26")
            image27.image = UIImage(named: "w27")
            image31.image = UIImage(named: "w31")
            image32.image = UIImage(named: "w32")
            image33.image = UIImage(named: "w33")
            image34.image = UIImage(named: "w34")
            image35.image = UIImage(named: "w35")
            image36.image = UIImage(named: "w36")
            image37.image = UIImage(named: "w37")
//            bingoView.alpha = 0
//            bingoViewTwo.alpha = 0
//            bingoViewThree.alpha = 0
//
            
            
            //            textView.text = "(请开始，我在听)"
            
            
        } else {
            recordButton.setBackgroundImage(UIImage(named: "readStop"), for: .normal)
            bingoView.alpha = 0
            bingoViewTwo.alpha = 0
            bingoViewThree.alpha = 0
            
            
            isSpeak = true
            do {
                
                try startRecording()
                
            } catch {
                
                print("erro")
                
            }
        }
        
    }
    
    private func startRecording() throws {
        
        //        print("1")
        
        recognitionTask?.cancel()
        self.recognitionTask = nil
        //        print("2")
        
        let audioSession = AVAudioSession.sharedInstance()
        try audioSession.setCategory(.record, mode: .measurement, options: .duckOthers)
        //        print("3")
        try audioSession.setActive(true, options: .notifyOthersOnDeactivation)
        //        print("4")
        let inputNode = audioEngine.inputNode
        
        // Create and configure the speech recognition request.
        recognitionRequest = SFSpeechAudioBufferRecognitionRequest()
        guard let recognitionRequest = recognitionRequest else { fatalError("Unable to create a SFSpeechAudioBufferRecognitionRequest object") }
        //        print("5")
        recognitionRequest.shouldReportPartialResults = true
        
        // Keep speech recognition data on device
        if #available(iOS 13, *) {
            recognitionRequest.requiresOnDeviceRecognition = false
        }
        
        recognitionTask = speechRecognizer.recognitionTask(with: recognitionRequest) { [self] result, error in
            var isFinal = false
            
            if let result = result {
                
                self.textView.text = result.bestTranscription.formattedString
                isFinal = result.isFinal
                print("Text \(result.bestTranscription.formattedString)")
                //                self.image1.image = UIImage(named: "w1")
            }
            
            if textView.text == "河里有只船船上挂白帆。" {
                image1.image = UIImage(named: "l1")
                image2.image = UIImage(named: "l2")
                image3.image = UIImage(named: "l3")
                image4.image = UIImage(named: "l4")
                image5.image = UIImage(named: "l5")
                image6.image = UIImage(named: "l6")
                image7.image = UIImage(named: "l7")
                image8.image = UIImage(named: "l8")
                image9.image = UIImage(named: "l9")
                image10.image = UIImage(named: "l10")
                //                textView.text =
                bingoView.alpha = 1
                bingoViewTwo.alpha = 0
                bingoViewThree.alpha = 0
//                bingoView.image = UIImage(named: "erro")
                print("true")
                
            } else {
                
                bingoView.alpha = 1
                bingoViewTwo.alpha = 0
                bingoViewThree.alpha = 0
                bingoView.image = UIImage(named: "erro")
                print("erro")
                
            }
            
            if textView.text == "河里有只船船上挂白帆，风吹翻张传向前。" {
                image1.image = UIImage(named: "l1")
                image2.image = UIImage(named: "l2")
                image3.image = UIImage(named: "l3")
                image4.image = UIImage(named: "l4")
                image5.image = UIImage(named: "l5")
                image6.image = UIImage(named: "l6")
                image7.image = UIImage(named: "l7")
                image8.image = UIImage(named: "l8")
                image9.image = UIImage(named: "l9")
                image10.image = UIImage(named: "l10")
                image21.image = UIImage(named: "l21")
                image22.image = UIImage(named: "l22")
                image23.image = UIImage(named: "l23")
                image24.image = UIImage(named: "l24")
                image25.image = UIImage(named: "l25")
                image26.image = UIImage(named: "l26")
                image27.image = UIImage(named: "l27")
                print("true")
                bingoView.alpha = 1
                bingoViewTwo.alpha = 1
                bingoViewThree.alpha = 0
//                bingoView.image = UIImage(named: "erro")
                
            } else {
                
                bingoView.alpha = 1
                bingoViewTwo.alpha = 1
                bingoViewThree.alpha = 0
                bingoViewTwo.image = UIImage(named: "erro")
                
                print("erro")
                
            }
            
            if textView.text == "河里有只船船上挂白帆，风吹翻张传向前无风翻落停下传。" {
                image1.image = UIImage(named: "l1")
                image2.image = UIImage(named: "l2")
                image3.image = UIImage(named: "l3")
                image4.image = UIImage(named: "l4")
                image5.image = UIImage(named: "l5")
                image6.image = UIImage(named: "l6")
                image7.image = UIImage(named: "l7")
                image8.image = UIImage(named: "l8")
                image9.image = UIImage(named: "l9")
                image10.image = UIImage(named: "l10")
                image21.image = UIImage(named: "l21")
                image22.image = UIImage(named: "l22")
                image23.image = UIImage(named: "l23")
                image24.image = UIImage(named: "l24")
                image25.image = UIImage(named: "l25")
                image26.image = UIImage(named: "l26")
                image27.image = UIImage(named: "l27")
                image31.image = UIImage(named: "l31")
                image32.image = UIImage(named: "l32")
                image33.image = UIImage(named: "l33")
                image34.image = UIImage(named: "l34")
                image35.image = UIImage(named: "l35")
                image36.image = UIImage(named: "l36")
                image37.image = UIImage(named: "l37")
                textView.text = "(请开始，我在听)"
                bingoView.alpha = 1
                bingoViewTwo.alpha = 1
                bingoViewThree.alpha = 1
//                bingoView.image = UIImage(named: "erro")
                print("true")
                
            } else {
                
                bingoView.alpha = 1
                bingoViewTwo.alpha = 1
                bingoViewThree.alpha = 1
                bingoViewThree.image = UIImage(named: "erro")
                print("erro")
                
            }
            
            //            if textView.text == "河里有只船船上挂白帆，风吹翻张船向前无风翻落停下船" {
            //                image1.image = UIImage(named: "w1")
            //                image2.image = UIImage(named: "w2")
            //                image3.image = UIImage(named: "w3")
            //                image4.image = UIImage(named: "w4")
            //                image5.image = UIImage(named: "w5")
            //                image6.image = UIImage(named: "w6")
            //                image7.image = UIImage(named: "w7")
            //                image8.image = UIImage(named: "w8")
            //                image9.image = UIImage(named: "w9")
            //                image10.image = UIImage(named: "w10")
            //                image21.image = UIImage(named: "w21")
            //                image22.image = UIImage(named: "w22")
            //                image23.image = UIImage(named: "w23")
            //                image24.image = UIImage(named: "w24")
            //                image25.image = UIImage(named: "w25")
            //                image26.image = UIImage(named: "w26")
            //                image27.image = UIImage(named: "w27")
            //                image31.image = UIImage(named: "w31")
            //                image32.image = UIImage(named: "w32")
            //                image33.image = UIImage(named: "w33")
            //                image34.image = UIImage(named: "w34")
            //                image35.image = UIImage(named: "w35")
            //                image36.image = UIImage(named: "w36")
            //                image37.image = UIImage(named: "w37")
            //                print("true")
            //
            //            } else {
            //
            //                print("erro")
            //
            //            }
            
            //            if textView.text == "河里" {
            //                image2.image = UIImage(named: "l2")
            //                print("true")
            //            } else {
            //
            //                print("erro")
            //
            //            }
            //
            //            if textView.text == "河里有" {
            //                image3.image = UIImage(named: "l3")
            //                print("true")
            //            } else {
            //
            //                print("erro")
            //
            //            }
            //
            //            if textView.text == "河里有只" {
            //                image4.image = UIImage(named: "l4")
            //                print("true")
            //            } else {
            //
            //                print("erro")
            //
            //            }
            //
            //            if textView.text == "河里有只船" {
            //                image5.image = UIImage(named: "l5")
            //                print("true")
            //            } else {
            //
            //                print("erro")
            //
            //            }
            //
            //            if textView.text == "河里有只船船" {
            //                image6.image = UIImage(named: "l6")
            //                print("true")
            //            } else {
            //
            //                print("erro")
            //
            //            }
            //
            ////            if textView.text == "河里有只船船" {
            ////                image1.image = UIImage(named: "l1")
            ////                print("true")
            ////            } else {
            ////
            ////                print("erro")
            ////
            ////            }
            //
            //            if textView.text == "河里有只船船上" {
            //                image7.image = UIImage(named: "l7")
            //                print("true")
            //            } else {
            //
            //                print("erro")
            //
            //            }
            //
            //            if textView.text == "河里有只船船上挂" {
            //                image8.image = UIImage(named: "l8")
            //                print("true")
            //            } else {
            //
            //                print("erro")
            //
            //            }
            //
            //            if textView.text == "河里有只船船上挂白" {
            //                image9.image = UIImage(named: "l9")
            //                print("true")
            //            } else {
            //
            //                print("erro")
            //
            //            }
            //
            //            if textView.text == "河里有只船船上挂白帆" {
            //                image10.image = UIImage(named: "l10")
            //                print("true")
            //            } else {
            //
            //                print("erro")
            //
            //            }
            
            if error != nil || isFinal {
                // Stop recognizing speech if there is a problem.
                self.audioEngine.stop()
                inputNode.removeTap(onBus: 0)
                
                self.recognitionRequest = nil
                self.recognitionTask = nil
                
                self.recordButton.isEnabled = true
                self.recordButton.setTitle("", for: [])
            }
        }
        
        // Configure the microphone input.
        let recordingFormat = inputNode.outputFormat(forBus: 0)
        inputNode.installTap(onBus: 0, bufferSize: 1024, format: recordingFormat) { (buffer: AVAudioPCMBuffer, when: AVAudioTime) in
            self.recognitionRequest?.append(buffer)
        }
        
        audioEngine.prepare()
        try audioEngine.start()
        
        // Let the user know to start talking.
        textView.text = "(请开始，我在听)"
    }
    
    // MARK: SFSpeechRecognizerDelegate
    
    public func speechRecognizer(_ speechRecognizer: SFSpeechRecognizer, availabilityDidChange available: Bool) {
        if available {
            recordButton.isEnabled = true
            recordButton.setTitle("", for: [])
        } else {
            recordButton.isEnabled = false
            recordButton.setTitle("无法得到认可", for: .disabled)
        }
    }
    
    // MARK: Interface Builder actions
    public func recordButtonTapped() {
        if audioEngine.isRunning {
            audioEngine.stop()
            recognitionRequest?.endAudio()
            recordButton.isEnabled = false
            recordButton.setTitle("", for: .disabled)
            
            
        } else {
            do {
                try startRecording()
                recordButton.setTitle("结束", for: [])
            } catch {
                recordButton.setTitle("语音不可用", for: [])
            }
        }
    }
}

