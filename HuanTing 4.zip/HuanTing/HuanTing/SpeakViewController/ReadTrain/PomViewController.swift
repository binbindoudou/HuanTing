//
//  PomViewController.swift
//  HuanTing
//
//  Created by Jung Jessica on 2022/8/30.
//

import UIKit
import Speech
import AVFoundation

class PomViewController: UIViewController, SFSpeechRecognizerDelegate {
    
    @IBOutlet weak var textView: UITextView!
    @IBOutlet weak var microphoneButton: UIButton!
    
    private let speechRecognizer = SFSpeechRecognizer(locale: Locale.init(identifier:"en-US"))
    
    var pomBackground: UIImageView!
    var pomWord: UIImageView!
    var pomGround: UIImageView!
    var pombackButton: UIButton!

    override func viewDidLoad() {
        super.viewDidLoad()
        
        pombackButton = UIButton(frame: CGRect(x: view.frame.width/40, y: view.frame.height/26, width: view.frame.width/8, height: view.frame.height/6))
        pombackButton.setBackgroundImage(UIImage(named: "back"), for: .normal)
        pombackButton.addTarget(self, action: #selector(clickPomOne), for:.touchUpInside)
        
        pomBackground = UIImageView(frame: CGRect(x: 0, y: 0, width: view.frame.width, height: view.frame.height))
        pomBackground.image = UIImage(named: "backgroundBlue")
        
        pomWord = UIImageView(frame: CGRect(x: view.frame.width/20, y: view.frame.height*4/20, width: view.frame.width*4/10, height: view.frame.height*4/6))
        pomWord.image = UIImage(named: "pomWord")
        
        pomGround = UIImageView(frame: CGRect(x: view.frame.width*11/20, y: view.frame.height*4/20, width: view.frame.width*4/10, height: view.frame.height*4/6))
        pomGround.image = UIImage(named: "pomGround")
        
        microphoneButton.isEnabled = false
        
        SFSpeechRecognizer.requestAuthorization { (authStatus) in
            
            var isButtonEnabled = false
            
            switch authStatus {
            case .authorized:
                isButtonEnabled = true
                
            case .denied:
                isButtonEnabled = false
                print("用户拒绝访问语音访问")
                
            case .restricted:
                isButtonEnabled = false
                print("此设备不支持语音识别")
                
            case .notDetermined:
                isButtonEnabled = false
                print("语音功能未授权")
                
            }
            
            OperationQueue.main.addOperation {
                
                self.microphoneButton.isEnabled = isButtonEnabled
                
            }
            
        }
        
        self.view.addSubview(pomBackground)
        self.view.addSubview(pombackButton)
        self.view.addSubview(pomWord)
        self.view.addSubview(pomGround)
        
    }
    
    @objc func clickPomOne() {
        
        let pomback = SpeakViewController()
        pomback.modalPresentationStyle = .fullScreen
        self.present(pomback, animated: true, completion: nil)
        
    }
    
    @IBAction func microphoneTapped(_ sender: AnyObject) {
        
    }
    
}


