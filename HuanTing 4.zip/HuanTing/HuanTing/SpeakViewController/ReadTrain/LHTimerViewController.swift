//
//  LHTimerViewController.swift
//  HuanTing
//
//  Created by Jung Jessica on 2022/9/1.
//

import UIKit

import UIKit

class LHTimerViewController: UIViewController {

    var timeLabel: UILabel!
    var startButton: UIButton!
    var pauseButton: UIButton!
    var counter = 0.0
    var timer = Timer()
    var isPlaying = false
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        
        timeLabel.text = String(counter)
        pauseButton.isEnabled = false
        
    }
    
    
    

}
