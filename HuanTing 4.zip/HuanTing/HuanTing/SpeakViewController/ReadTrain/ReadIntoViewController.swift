//
//  ReadIntoViewController.swift
//  HuanTing
//
//  Created by Jung Jessica on 2022/8/30.
//

import UIKit

class ReadIntoViewController: UIViewController {
    
    var readIntoBackground: UIImageView!
    var readBackground: UIImageView!
    var readbackButton: UIButton!
    var readButton: UIButton!

    override func viewDidLoad() {
        super.viewDidLoad()

        readbackButton = UIButton(frame: CGRect(x: view.frame.width/40, y: view.frame.height/26, width: view.frame.width/8, height: view.frame.height/6))
        readbackButton.setBackgroundImage(UIImage(named: "back"), for: .normal)
        readbackButton.addTarget(self, action: #selector(clickReadOne), for:.touchUpInside)
        
        readBackground = UIImageView(frame: CGRect(x: 0, y: 0, width: view.frame.width, height: view.frame.height))
        readBackground.image = UIImage(named: "background")
        
        readIntoBackground = UIImageView(frame: CGRect(x: view.frame.width/20, y: view.frame.height*2/15, width: view.frame.width*18/20, height: view.frame.height*11/15))
        readIntoBackground.image = UIImage(named: "backgroundThree")
        
        readButton = UIButton(frame: CGRect(x: view.frame.width*8/24, y: view.frame.height*23/32, width: view.frame.width*4/12, height: view.frame.height/5))
        readButton.setBackgroundImage(UIImage(named: "mouthAction"), for: .normal)
        readButton.addTarget(self, action: #selector(clickReadTwo), for:.touchUpInside)
        
        self.view.addSubview(readBackground)
        self.view.addSubview(readbackButton)
        self.view.addSubview(readIntoBackground)
        self.view.addSubview(readButton)
        
    }
    
    @objc func clickReadOne() {
        
        let readback = SpeakViewController()
        readback.modalPresentationStyle = .fullScreen
        self.present(readback, animated: true, completion: nil)
        
    }
    
    @objc func clickReadTwo() {
        
//        var storyboard = UIStoryboard(name: "Main", bundle: nil)
//        var read: PoertyViewController = storyboard.instantiateViewController(withIdentifier: "Poetry") as! PoertyViewController
        let read = PoertyViewController()
        read.modalPresentationStyle = .fullScreen
        self.present(read, animated: true, completion: nil)
        
    }

}
