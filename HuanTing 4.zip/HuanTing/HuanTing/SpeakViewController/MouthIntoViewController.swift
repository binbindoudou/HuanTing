//
//  MouthIntoViewController.swift
//  HuanTing
//
//  Created by Jung Jessica on 2022/8/30.
//

import UIKit

class MouthIntoViewController: UIViewController {
    
    var mouthIntoBackground: UIImageView!
    var mouthBackground: UIImageView!
    var mouthbackButton: UIButton!
    var mouthButton: UIButton!

    override func viewDidLoad() {
        super.viewDidLoad()
        
        mouthbackButton = UIButton(frame: CGRect(x: view.frame.width/40, y: view.frame.height/26, width: view.frame.width/8, height: view.frame.height/6))
        mouthbackButton.setBackgroundImage(UIImage(named: "back"), for: .normal)
        mouthbackButton.addTarget(self, action: #selector(clickMouthOne), for:.touchUpInside)
        
        mouthBackground = UIImageView(frame: CGRect(x: 0, y: 0, width: view.frame.width, height: view.frame.height))
        mouthBackground.image = UIImage(named: "background")
        
        mouthIntoBackground = UIImageView(frame: CGRect(x: 0, y: 0, width: view.frame.width, height: view.frame.height))
        mouthIntoBackground.image = UIImage(named: "backgroundTwo")
        
        mouthButton = UIButton(frame: CGRect(x: view.frame.width*8/24, y: view.frame.height*6/8, width: view.frame.width*4/12, height: view.frame.height/5))
        mouthButton.setBackgroundImage(UIImage(named: "mouthAction"), for: .normal)
        mouthButton.addTarget(self, action: #selector(clickMouthTwo), for:.touchUpInside)
        
        self.view.addSubview(mouthBackground)
        self.view.addSubview(mouthbackButton)
        self.view.addSubview(mouthIntoBackground)
        self.view.addSubview(mouthButton)
        
    }
    
    @objc func clickMouthOne() {
        
        let readback = SpeakViewController()
        readback.modalPresentationStyle = .fullScreen
        self.present(readback, animated: true, completion: nil)
        
    }
    
    @objc func clickMouthTwo() {
        
//        var storyboard = UIStoryboard(name: "Main", bundle: nil)
//        var mouth: ARViewController = storyboard.instantiateViewController(withIdentifier: "Mouth") as! ARViewController
        let mouth = ARViewController()
        mouth.modalPresentationStyle = .fullScreen
        self.present(mouth, animated: true, completion: nil)
        
    }
    
}
