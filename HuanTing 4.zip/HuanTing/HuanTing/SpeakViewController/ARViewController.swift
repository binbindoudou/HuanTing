//
//  AViewController.swift
//  HuanTing
//
//  Created by Jung Jessica on 2022/8/30.
//

import UIKit
import SceneKit
import ARKit

class ARViewController: UIViewController, ARSCNViewDelegate {
    
    var ARViewbackButton: UIButton!
    var sceneView: ARSCNView!
    var ARBackground: UIImageView!
    var lableView: UIView!
    var faceLabel: UILabel!
    var tOF: UIImageView!
//    var choiceO: UIImageView!
    //    @IBOutlet var sceneView: SCNView!
//    @IBOutlet var sceneView: ARSCNView!
//    @IBOutlet weak var labelView: UIView!
    //    @IBOutlet weak var faceLabel: UILabel!
//    @IBOutlet weak var faceLabel: UILabel!
    //    @IBOutlet weak var labelView: UIView!
    var analysis = ""

    override func viewDidLoad() {
        
        super.viewDidLoad()
        
        ARViewbackButton = UIButton(frame: CGRect(x: view.frame.width/40, y: view.frame.height/26, width: view.frame.width/8, height: view.frame.height/6))
        ARViewbackButton.setBackgroundImage(UIImage(named: "back"), for: .normal)
        ARViewbackButton.addTarget(self, action: #selector(clickAROne), for:.touchUpInside)
        
        sceneView = ARSCNView(frame: CGRect(x: 0, y: 0, width: view.frame.width, height: view.frame.height))
        
        ARBackground = UIImageView(frame: CGRect(x: view.frame.width*2/26, y: view.frame.height*6/26, width: view.frame.width/4, height: view.frame.height/2))
        ARBackground.image = UIImage(named: "backgroundBlueTwo")
        
        lableView = UIView(frame: CGRect(x: view.frame.width*21/26, y: view.frame.height*6/26, width: view.frame.width/6, height: view.frame.height/3))
        
//        labelView.layer.cornerRadius = 10
        faceLabel = UILabel(frame: CGRect(x: view.frame.width*21/26, y: view.frame.height*6/26, width: view.frame.width/6, height: view.frame.height/3))
        
        tOF = UIImageView(frame: CGRect(x: view.frame.width*9/52, y: view.frame.height*13/26, width: view.frame.width/8, height: view.frame.height/6))
        tOF.image = UIImage(named: "false")
        
                
        sceneView.delegate = self
        sceneView.showsStatistics = true
        
        self.view.addSubview(faceLabel)
        self.view.addSubview(sceneView)
        self.view.addSubview(lableView)
        self.view.addSubview(ARBackground)
        self.view.addSubview(ARViewbackButton)
        self.view.addSubview(tOF)
        
        guard ARFaceTrackingConfiguration.isSupported else {
            
            fatalError("无法识别您的口型")
            
            
        }
            
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        let configuration = ARFaceTrackingConfiguration()
        sceneView.session.run(configuration)
        
    }


    override func viewWillDisappear(_ animated: Bool) {
    
    super.viewWillDisappear(animated)
    sceneView.session.pause()
    
}
    
    @objc func clickAROne() {
        
        let ARback = SpeakViewController()
        ARback.modalPresentationStyle = .fullScreen
        self.present(ARback, animated: true, completion: nil)
        
    }
    
    func renderer(_ renderer: SCNSceneRenderer, nodeFor anchor: ARAnchor) -> SCNNode? {
        
        let faceMesh = ARSCNFaceGeometry(device: sceneView.device!)
        let node = SCNNode(geometry: faceMesh)
        node.geometry?.firstMaterial?.fillMode = .lines
        return node
        
    }

    func renderer(_ renderer: SCNSceneRenderer, didUpdate node: SCNNode, for anchor: ARAnchor) {
        
        if let faceAnchor = anchor as? ARFaceAnchor, let faceGeometry = node.geometry as? ARSCNFaceGeometry {
            
            faceGeometry.update(from: faceAnchor.geometry)
            expression(anchor: faceAnchor)
            
            DispatchQueue.main.async {
                
                self.faceLabel.text = self.analysis
                
            }
        }
    }

    func expression(anchor: ARFaceAnchor) {
        
        let mouthLeft = anchor.blendShapes[.mouthLeft]
        let mouthRight = anchor.blendShapes[.mouthRight]
        let jawOpen = anchor.blendShapes[.jawOpen]
        self.analysis = ""
            
        if ((mouthLeft?.decimalValue ?? 0.0) + (mouthRight?.decimalValue ?? 0.0)) + ((jawOpen?.decimalValue ?? 0.0)) > 0.8 {
            
            self.analysis += "o说真好 "
            tOF.image = UIImage(named: "true")
//            tOF = UIImageView(frame: CGRect(x: view.frame.width*9/52, y: view.frame.height*13/26, width: view.frame.width/8, height: view.frame.height/6))
            
        } else {
            
            self.analysis += "o再说一遍吧"
            tOF.image = UIImage(named: "false")
//            tOF = UIImageView(frame: CGRect(x: view.frame.width*9/52, y: view.frame.height*13/26, width: view.frame.width/8, height: view.frame.height/6))
//            tOF.image = UIImage(named: "false")
            
        }
    }
}
