//
//  SpeakViewController.swift
//  HuanTing
//
//  Created by Jung Jessica on 2022/8/30.
//

import UIKit

class SpeakViewController: UIViewController {
    
    var speakBackgound: UIImageView!
    var speakSign: UIImageView!
    var speakbackButton: UIButton!
    var mouthButton: UIButton!
    var readButton: UIButton!

    override func viewDidLoad() {
        super.viewDidLoad()

        speakbackButton = UIButton(frame: CGRect(x: view.frame.width/40, y: view.frame.height/26, width: view.frame.width/8, height: view.frame.height/6))
        speakbackButton.setBackgroundImage(UIImage(named: "back"), for: .normal)
        speakbackButton.addTarget(self, action: #selector(clickSpeakOne), for:.touchUpInside)
        
        speakBackgound = UIImageView(frame: CGRect(x: 0, y: 0, width: view.frame.width, height: view.frame.height))
        speakBackgound.image = UIImage(named: "background")
        
        speakSign = UIImageView(frame: CGRect(x: view.frame.width/10, y: view.frame.height/4, width: view.frame.width/4, height: view.frame.height*3/5))
        speakSign.image = UIImage(named: "speakButton")
        
        mouthButton = UIButton(frame: CGRect(x: view.frame.width*7/20, y: view.frame.height*4/20, width: view.frame.width*23/40, height: view.frame.height*11/40))
        mouthButton.setBackgroundImage(UIImage(named: "mouthTraining"), for: .normal)
        mouthButton.addTarget(self, action: #selector(clickSpeakTwo), for:.touchUpInside)
        
        readButton = UIButton(frame: CGRect(x: view.frame.width*7/20, y: view.frame.height*11/20, width: view.frame.width*23/40, height: view.frame.height*11/40))
        readButton.setBackgroundImage(UIImage(named: "readingTraining"), for: .normal)
        readButton.addTarget(self, action: #selector(clickSpeakThree), for:.touchUpInside)
        
        self.view.addSubview(speakBackgound)
        self.view.addSubview(speakbackButton)
        self.view.addSubview(speakSign)
        self.view.addSubview(mouthButton)
        self.view.addSubview(readButton)
        
    }
    
    @objc func clickSpeakOne() {
        
        let speakback = TrainModViewController()
        speakback.modalPresentationStyle = .fullScreen
        self.present(speakback, animated: true, completion: nil)
        
    }
    
    @objc func clickSpeakTwo() {
        
        let mouth = MouthIntoViewController()
        mouth.modalPresentationStyle = .fullScreen
        self.present(mouth, animated: true, completion: nil)
        
    }

    @objc func clickSpeakThree() {
        
        let read = ReadIntoViewController()
        read.modalPresentationStyle = .fullScreen
        self.present(read, animated: true, completion: nil)
        
    }


}
