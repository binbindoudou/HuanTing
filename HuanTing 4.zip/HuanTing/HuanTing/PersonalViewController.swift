//
//  PersonalViewController.swift
//  HuanTing
//
//  Created by Jung Jessica on 2022/8/30.
//

import UIKit
import Charts
import Foundation

class PersonalViewController: UIViewController {
    
    var personalBackButton: UIButton!
    var personalBackground: UIImageView!
    var personaIimage: UIImageView!
    var chartView: PieChartView!
    //雷达图
    var radarChartView: RadarChartView!
    
    //雷达图每个维度的标签文字
    let activities = ["自然声", "音节", "音乐轮廓", "口型训练", "朗读训练"]
    //    var lineChartView: LineChartView!
    var errTitle: UIImageView!
    var trainingHour: UIImageView!
    //    /// 定时器
    //    var displayLin: CADisplayLink?
    //
    //    /// 开始时间
    //    var startTime: TimeInterval = 0.0
    //
    //    /// 结束时间
    //    var endTime: TimeInterval = 0.0
    //
    //    /// 动画时间
    //    var duration: TimeInterval = 0.0
    //
    //    /// 更新界面回调
    //    var updateBlock: (() -> Void)?
    //
    //    /// 动画结束回调
    //    var stopBlock: (() -> Void)?
    //
    //    /// 更新进度
    //    var phaseX: Double = 1
    
    //    func animate(duration: TimeInterval) {
    //        self.startTime = CACurrentMediaTime()
    //        self.duration = duration
    //        self.endTime = startTime + duration
    //        self.preferredStatusBarUpdateAnimation(startTime)
    //        if self.displayLin == nil {
    //            self.displayLin = CADisplayLink(target: self, selector: #selector(animationLoop))
    //            self.displayLin?.add(to: .main, forMode: .common)
    //        }
    //
    //    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        personalBackground = UIImageView(frame: CGRect(x: 0, y: 0, width: view.frame.width, height: view.frame.height))
        personalBackground.image = UIImage(named: "background")
        
        personalBackButton = UIButton(frame: CGRect(x: view.frame.width/40, y: view.frame.height/26, width: view.frame.width/8, height: view.frame.height/6))
        personalBackButton.setBackgroundImage(UIImage(named: "back"), for: .normal)
        personalBackButton.addTarget(self, action: #selector(clickPersonalOne), for:.touchUpInside)
        
        personaIimage = UIImageView(frame: CGRect(x: 0, y: 0, width: view.frame.width, height: view.frame.height))
        personaIimage.image = UIImage(named: "backgroundPersonal")
        
        errTitle = UIImageView(frame: CGRect(x: view.frame.width*7/32, y: view.frame.height*3/16, width: view.frame.width/6, height: view.frame.height/8))
        errTitle.image = UIImage(named: "erroTitle")
        
        trainingHour = UIImageView(frame: CGRect(x: view.frame.width*21/32, y: view.frame.height*3/16, width: view.frame.width/6, height: view.frame.height/8))
        trainingHour.image = UIImage(named: "trainingHour")
        
        self.view.addSubview(personalBackground)
        self.view.addSubview(personalBackButton)
        self.view.addSubview(personaIimage)
        self.view.addSubview(errTitle)
        self.view.addSubview(trainingHour)
        
        chartView = PieChartView()
        chartView.frame = CGRect(x: self.view.bounds.width/7, y: self.view.bounds.height/3, width: self.view.bounds.width/3, height: self.view.bounds.height/2)
        self.chartView.drawHoleEnabled = true
        self.view.addSubview(chartView)
        chartView.usePercentValuesEnabled = true
        chartView.holeColor = UIColor.clear
        chartView.transparentCircleRadiusPercent = 0.5
        
        //数据
        let dataEntries = (0..<5).map { (i) -> PieChartDataEntry in
            return PieChartDataEntry(value: Double(arc4random_uniform(50) + 10),
                                     label: "错题数:\(i)")
        }
        //        let dateEntries = ""
        let chartDataSet = PieChartDataSet(entries: dataEntries, label: "数据统计")
        //设置颜色
        chartDataSet.colors = ChartColorTemplates.liberty()
        + ChartColorTemplates.liberty()
        + ChartColorTemplates.liberty()
        + ChartColorTemplates.liberty()
        + ChartColorTemplates.liberty()
        let chartData = PieChartData(dataSet: chartDataSet)
        //        ChartDataSet.sliceSpace = 3
        chartData.setValueTextColor(.systemCyan)
        
        //设置饼状图数据
        chartView.data = chartData
        
        
        let pFotmatter = NumberFormatter()
        pFotmatter.numberStyle = .percent
        pFotmatter.maximumFractionDigits = 1
        pFotmatter.multiplier = 1
        pFotmatter.percentSymbol = "%"
        chartData.setValueFormatter(DefaultValueFormatter(formatter: pFotmatter))
        
        //雷达图开始
        radarChartView = RadarChartView()
        radarChartView.frame = CGRect(x: view.frame.width*4/7, y: view.frame.height*7/18, width: view.frame.width/3, height: view.frame.height/2)
        self.view.addSubview(radarChartView)
        radarChartView.webLineWidth = 2 //网格主干线粗细
        radarChartView.webColor = .systemCyan //网格主干线颜色
        radarChartView.webAlpha = 1 //网格线透明度
        radarChartView.innerWebLineWidth = 1 //网格边线粗细
        radarChartView.innerWebColor = .systemCyan //网格边线颜色
        
        radarChartView.xAxis.valueFormatter = self
        //最小、最大刻度值
        let yAxis = radarChartView.yAxis
        yAxis.axisMinimum = 0
        yAxis.axisMaximum = 100
        yAxis.labelCount = 4
        yAxis.drawLabelsEnabled = false //不显示刻度值
        
        //数据
        let radarDataEntries = (0..<5).map { (i) -> RadarChartDataEntry in
            return RadarChartDataEntry(value: Double(arc4random_uniform(50) + 50))
        }
        let radarChartDataSet = RadarChartDataSet(entries: radarDataEntries, label: "")
        //目前雷达图只包括1组数据
        radarChartDataSet.setColor(.purple)
        radarChartDataSet.lineWidth = 2
        
        let radarChartData = RadarChartData(dataSets: [radarChartDataSet])
        radarChartData.setValueFont(.systemFont(ofSize: 8, weight: .light)) //数值文字字体
        radarChartData.setValueTextColor(.blue) //数值文字颜色
        
        //设置雷达图数据
        radarChartView.data = radarChartData
        
    }
    
    @objc func clickPersonalOne() {
        
        let personal = TrainModViewController()
        personal.modalPresentationStyle = .fullScreen
        self.present(personal, animated: true, completion: nil)
        
    }
    
}

extension PersonalViewController: AxisValueFormatter {
    //维度标签文字（x轴文字）
    func stringForValue(_ value: Double, axis: AxisBase?) -> String {
        return activities[Int(value) % activities.count]
    }
}
