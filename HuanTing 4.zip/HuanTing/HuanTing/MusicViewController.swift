//
//  MusicViewController.swift
//  HuanTing
//
//  Created by Jung Jessica on 2022/8/30.
//

import UIKit
import AVFoundation

class MusicViewController: UIViewController {
    var audioPlayer: AVAudioPlayer  = AVAudioPlayer()
    var musicBackground: UIImageView!
    var musicbackButton: UIButton!
    var musicButton: UIButton!
//    var musicSettingButton: UIButton!
    var nextButton: UIButton!
    var lastButton: UIButton!
    var One: UIButton!
    var Two: UIButton!
    var Three: UIButton!
    var Four: UIButton!
    var musictrueimageView: UIImageView!
    var musicerroimageView: UIImageView!
    var musicisPlaying: Bool = false
    

    override func viewDidLoad() {
        
        super.viewDidLoad()

        musicbackButton = UIButton(frame: CGRect(x: view.frame.width/40, y: view.frame.height/26, width: view.frame.width/8, height: view.frame.height/6))
        musicbackButton.setBackgroundImage(UIImage(named: "back"), for: .normal)
        musicbackButton.addTarget(self, action: #selector(clickMusicOne), for:.touchUpInside)
        
        musicBackground = UIImageView(frame: CGRect(x: 0, y: 0, width: view.frame.width, height: view.frame.height))
        musicBackground.image = UIImage(named: "background")
        
//        musicSettingButton = UIButton(frame: CGRect(x: view.frame.width*7/8, y: view.frame.height/50, width: view.frame.width/8, height: view.frame.height/6))
//        musicSettingButton.setBackgroundImage(UIImage(named: "setting"), for: .normal)
//        musicSettingButton.addTarget(self, action: #selector(clickMusicTwo), for:.touchUpInside)
        
        One = UIButton(frame: CGRect(x: view.frame.width*4/60, y: view.frame.height*11/40, width: view.frame.width/6, height: view.frame.height/5))
        One.setBackgroundImage(UIImage(named: "1"), for: .normal)
        One.addTarget(self, action: #selector(clickMusicThree), for:.touchUpInside)
        
        Two = UIButton(frame: CGRect(x: view.frame.width*18/60, y: view.frame.height*8/40, width: view.frame.width/6, height: view.frame.height/6))
        Two.setBackgroundImage(UIImage(named: "2"), for: .normal)
        Two.addTarget(self, action: #selector(clickMusicFour), for:.touchUpInside)
        
        Three = UIButton(frame: CGRect(x: view.frame.width*32/60, y: view.frame.height*8/40, width: view.frame.width/6, height: view.frame.height/6))
        Three.setBackgroundImage(UIImage(named: "3"), for: .normal)
        Three.addTarget(self, action: #selector(clickMusicFive), for:.touchUpInside)
        
        Four = UIButton(frame: CGRect(x: view.frame.width*46/60, y: view.frame.height*11/40, width: view.frame.width/6, height: view.frame.height/5))
        Four.setBackgroundImage(UIImage(named: "4"), for: .normal)
        Four.addTarget(self, action: #selector(clickMusicSix), for:.touchUpInside)
        
        musicButton = UIButton(frame: CGRect(x: view.frame.width*7/16, y: view.frame.height*15/28, width: view.frame.width/8, height: view.frame.height/7))
        musicButton.setBackgroundImage(UIImage(named: "startButton"), for: .normal)
        musicButton.addTarget(self, action: #selector(clickMusicSeven), for:.touchUpInside)
        
        lastButton = UIButton(frame: CGRect(x: view.frame.width*2/9, y: view.frame.height*5/7, width: view.frame.width*2/9, height: view.frame.height/7))
        lastButton.setBackgroundImage(UIImage(named: "lastButton"), for: .normal)
        lastButton.addTarget(self, action: #selector(clickMusicEight), for:.touchUpInside)
        
        nextButton = UIButton(frame: CGRect(x: view.frame.width*5/9, y: view.frame.height*5/7, width: view.frame.width*2/9, height: view.frame.height/7))
        nextButton.setBackgroundImage(UIImage(named: "nextButton"), for: .normal)
        nextButton.addTarget(self, action: #selector(clickMusicNine), for:.touchUpInside)
        
        musictrueimageView = UIImageView(frame: CGRect(x: 0, y: 0, width: 600, height: 300))
        musictrueimageView.center = view.center
        musictrueimageView.image = UIImage(named: "bingoSign")
        musictrueimageView.alpha = 0
        
        musicerroimageView = UIImageView(frame: CGRect(x: 0, y: 0, width: 600, height: 300))
        musicerroimageView.center = view.center
        musicerroimageView.image = UIImage(named: "erroSign")
        musicerroimageView.alpha = 0
        
        let tap = UITapGestureRecognizer(target: self, action: #selector(alphaChange))

        view.addGestureRecognizer(tap)
        
//        buttonChoose()
        self.view.addSubview(musicBackground)
        self.view.addSubview(musicbackButton)
//        self.view.addSubview(musicSettingButton)
        self.view.addSubview(One)
        self.view.addSubview(Two)
        self.view.addSubview(Three)
        self.view.addSubview(Four)
        self.view.addSubview(musicButton)
        self.view.addSubview(lastButton)
        self.view.addSubview(nextButton)
        self.view.addSubview(musictrueimageView)
        self.view.addSubview(musicerroimageView)
//        self.view.addSubview(musicisPlaying)
//        buttonChoose()
        
    }
    func radio(name: String) {
        
        let musicUrl = NSURL(fileURLWithPath: Bundle.main.path(forResource: name, ofType: "mp3")!)
        do {
            try audioPlayer = AVAudioPlayer(contentsOf: musicUrl as URL)
            audioPlayer.prepareToPlay()
            audioPlayer.play()
//            audioPlayer.pause()
            audioPlayer.numberOfLoops = 0
            audioPlayer.volume = 1
        } catch {
            print("播放错误")
        }
    }
    
    func addTap() {
        
    }
    
    @objc func alphaChange() {
        
        if musictrueimageView.alpha == 1 || musicerroimageView.alpha == 1 {
            musictrueimageView.alpha = 0
            musicerroimageView.alpha = 0
        }else {
            
            print("cuowu")
        }
            
    }
    
    @objc func clickMusicOne() {
        
        let musicback = ListenViewController()
        musicback.modalPresentationStyle = .fullScreen
        self.present(musicback, animated: true, completion: nil)
        
    }
//    
//    @objc func clickMusicTwo() {
//        
//        let listenback = TrainModViewController()
//        listenback.modalPresentationStyle = .fullScreen
//        self.present(listenback, animated: true, completion: nil)
//        
//    }
    
    @objc func clickMusicThree() {
        //判断正确的是那个
        musictrueimageView.alpha = 1
        musicerroimageView.alpha = 0
    }
    
    @objc func clickMusicFour() {
        musictrueimageView.alpha = 0
        musicerroimageView.alpha = 1
    }
    
    @objc func clickMusicFive() {
        musictrueimageView.alpha = 0
        musicerroimageView.alpha = 1
    }
    
    @objc func clickMusicSix() {
        musictrueimageView.alpha = 0
        musicerroimageView.alpha = 1
    }
    
    @objc func clickMusicSeven() {
        
        
        radio(name: "1")
//        musicButton.setBackgroundImage(UIImage(), for: <#T##UIControl.State#>)
        
    }
    
    @objc func clickMusicEight() {
        let musicnext = MusicSixViewController()
        musicnext.modalPresentationStyle = .fullScreen
        self.present(musicnext, animated: true, completion: nil)
    }
    
    @objc func clickMusicNine() {
        let musiclast = MusicTwoViewController()
        musiclast.modalPresentationStyle = .fullScreen
        self.present(musiclast, animated: true, completion: nil)
    }
}
