//
//  SyllableTwoViewController.swift
//  HuanTing
//
//  Created by Jung Jessica on 2022/8/31.
//

import UIKit

class SyllableTwoViewController: SyllableViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        super.syllableOne.setBackgroundImage(UIImage(named: "u"), for: .normal)
        view.addSubview(super.syllableOne)
        
        super.syllableTwo.setBackgroundImage(UIImage(named: "v"), for: .normal)
        view.addSubview(super.syllableTwo)
        
        super.syllableThree.setBackgroundImage(UIImage(named: "ie"), for: .normal)
        view.addSubview(super.syllableThree)
        
        super.syllableFour.setBackgroundImage(UIImage(named: "ve"), for: .normal)
        view.addSubview(super.syllableFour)
        
//        super.syllableFour.addTarget(self.syllableFour, action: #selector(clickSyllableSix), for: .touchUpInside)
        
        view.addSubview(syllabletrueimageView)
        view.addSubview(syllableerroimageView)
        
        
    }
    @objc override func clickSyllableThree() {
        //判断正确的是那个
        syllabletrueimageView.alpha = 0
        syllableerroimageView.alpha = 1
    }
    
    @objc override func clickSyllableFour() {
        syllabletrueimageView.alpha = 0
        syllableerroimageView.alpha = 1
    }
    
    @objc override func clickSyllableFive() {
        syllabletrueimageView.alpha = 0
        syllableerroimageView.alpha = 1
    }
    
    @objc override func clickSyllableSix() {
        syllabletrueimageView.alpha = 1
        syllableerroimageView.alpha = 0
    }
    
    @objc override func clickSyllableEight() {
        let syllablelast = SyllableViewController()
        syllablelast.modalPresentationStyle = .fullScreen
        self.present(syllablelast, animated: true, completion: nil)
    }
    
    @objc override func clickSyllableNine() {
        let syllablenext = SyllableThreeViewController()
        syllablenext.modalPresentationStyle = .fullScreen
        self.present(syllablenext, animated: true, completion: nil)
    }

    @objc override func clickSyllableSeven() {
        
        radioSyllable(name: "8")
        
    }
    
}
